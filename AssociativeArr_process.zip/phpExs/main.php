<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercise</title>
<style>
    body{
        background:url("n2.jpg");
        background-size:cover;
    }
h1{
    margin:10px auto;

}
td{
    border:1px solid black;
    
}
tr{
    border:1px solid black;
}

table{
    border-collapse:collapse;
    margin:60px auto;
}

th{
    text-align:center;
    background-color:grey;
    font-weight:bold;
    
}

#max{
    color:green;
}

</style>
</head>

<body>

<h1>Class Rosters</h1>
   


  
    <?php 
    require "./db.php";
    echo "<table id='grades'>" ;

foreach($courses as $course_id =>$course_data)
{echo "<tr><th colspan='3'>{$course_id }:{$course_data['name']}</th></tr>";
   echo "<tr><td>Name</td><td>Surname</td><td>CGPA</td></tr> ";
    foreach($register as $reg)
     {  if($course_id===$reg['course_id'])
        {  $stu_data=getStu($reg['std_id']);
            echo "<tr><td>{$stu_data['name']}</td><td>{$stu_data['surname']}</td><td class='cgpa'>{$stu_data['cgpa']}</td><tr>" ;
          

        }
            
     }
}



echo "</table>" ;

function getStu($id)
{ global $students;
      foreach($students as $stu )
      {
        if( $stu['id'] ===$id)
        return $stu;

      }
}


?>



   
</body>
</html>